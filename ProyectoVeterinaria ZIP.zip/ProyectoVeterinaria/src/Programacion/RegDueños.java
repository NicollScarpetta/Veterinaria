/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Programacion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import Programacion.PgPrincipalVeterinaria;

/**
 *
 * @author nicol
 */
public class RegDueños extends javax.swing.JFrame {

    private int selectedRow;

    
    public RegDueños() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        botonCerrar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nombreDueño = new javax.swing.JTextField();
        cedulaDueño = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        edadDueño = new javax.swing.JTextField();
        celularDueño = new javax.swing.JTextField();
        direccionDueño = new javax.swing.JTextField();
        correoDueño = new javax.swing.JTextField();
        botonRegistrarDue = new javax.swing.JButton();
        botonCanceDueños = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        botonGuardar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaDueños = new javax.swing.JTable();
        botonBusquedaTDueños = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        busquedaNombre = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        botonBuscarCedula = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        busquedaCedula = new javax.swing.JTextField();
        botonBuscarNombre = new javax.swing.JButton();
        botonEliminarDueños = new javax.swing.JButton();
        botonLimpiar = new javax.swing.JButton();
        botonActualizarDueños = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(171, 221, 220));

        botonCerrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonCerrar.setText("Cerrar");
        botonCerrar.setToolTipText("");
        botonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerrarActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(171, 221, 220));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Registro Dueños");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectobases/Veterinaria/registro.png"))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Nombre Completo: ");

        nombreDueño.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nombreDueño.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        nombreDueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreDueñoActionPerformed(evt);
            }
        });

        cedulaDueño.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cedulaDueño.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        cedulaDueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cedulaDueñoActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Cédula de Ciudadanía:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Edad: ");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Celular:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Dirección: ");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("E-mail: ");

        edadDueño.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        edadDueño.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        edadDueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edadDueñoActionPerformed(evt);
            }
        });

        celularDueño.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        celularDueño.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        celularDueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                celularDueñoActionPerformed(evt);
            }
        });

        direccionDueño.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        direccionDueño.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        direccionDueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                direccionDueñoActionPerformed(evt);
            }
        });

        correoDueño.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        correoDueño.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        correoDueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                correoDueñoActionPerformed(evt);
            }
        });

        botonRegistrarDue.setBackground(new java.awt.Color(171, 221, 220));
        botonRegistrarDue.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonRegistrarDue.setText("Registrar");
        botonRegistrarDue.setToolTipText("");
        botonRegistrarDue.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonRegistrarDue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarDueActionPerformed(evt);
            }
        });

        botonCanceDueños.setBackground(new java.awt.Color(171, 221, 220));
        botonCanceDueños.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonCanceDueños.setText("Cancelar");
        botonCanceDueños.setToolTipText("");
        botonCanceDueños.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonCanceDueños.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCanceDueñosActionPerformed(evt);
            }
        });

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectobases/Veterinaria/registro.png"))); // NOI18N

        botonGuardar.setBackground(new java.awt.Color(171, 221, 220));
        botonGuardar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonGuardar.setText("Guardar Cambios");
        botonGuardar.setToolTipText("");
        botonGuardar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jLabel2)
                        .addGap(44, 44, 44)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(jLabel9))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(63, 63, 63)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel7)
                                        .addComponent(jLabel8)))
                                .addGap(47, 47, 47))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(botonRegistrarDue, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cedulaDueño, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nombreDueño, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(edadDueño, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(celularDueño, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(direccionDueño, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(correoDueño, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(botonCanceDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(70, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(162, 162, 162))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel2))))
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(nombreDueño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cedulaDueño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(edadDueño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(celularDueño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(direccionDueño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(correoDueño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(48, 48, 48)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonRegistrarDue, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonCanceDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        tablaDueños.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre Dueño", "Cedula (ID)", "Edad", "Celular", "Dirección", "E-mail"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaDueños.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tablaDueñosAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(tablaDueños);

        botonBusquedaTDueños.setBackground(new java.awt.Color(171, 221, 220));
        botonBusquedaTDueños.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonBusquedaTDueños.setText("Filtrar datos");
        botonBusquedaTDueños.setToolTipText("");
        botonBusquedaTDueños.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonBusquedaTDueños.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBusquedaTDueñosActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Dueño:");

        busquedaNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        busquedaNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        busquedaNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaNombreActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Cédula (ID):");

        botonBuscarCedula.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectobases/Veterinaria/lupita.png"))); // NOI18N
        botonBuscarCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarCedulaActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(171, 221, 220));

        jLabel10.setBackground(new java.awt.Color(171, 221, 220));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Listado Dueños");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        busquedaCedula.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        busquedaCedula.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        busquedaCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaCedulaActionPerformed(evt);
            }
        });

        botonBuscarNombre.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectobases/Veterinaria/lupita.png"))); // NOI18N
        botonBuscarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarNombreActionPerformed(evt);
            }
        });

        botonEliminarDueños.setBackground(new java.awt.Color(171, 221, 220));
        botonEliminarDueños.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonEliminarDueños.setText("Eliminar Dato");
        botonEliminarDueños.setToolTipText("");
        botonEliminarDueños.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonEliminarDueños.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarDueñosActionPerformed(evt);
            }
        });

        botonLimpiar.setBackground(new java.awt.Color(171, 221, 220));
        botonLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonLimpiar.setText("Limpiar");
        botonLimpiar.setToolTipText("");
        botonLimpiar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });

        botonActualizarDueños.setBackground(new java.awt.Color(171, 221, 220));
        botonActualizarDueños.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonActualizarDueños.setText("Actualizar Dato");
        botonActualizarDueños.setToolTipText("");
        botonActualizarDueños.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonActualizarDueños.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarDueñosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(261, 261, 261))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 727, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(18, 18, 18)
                                .addComponent(busquedaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(botonBuscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(busquedaCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(botonBuscarCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(botonBusquedaTDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(botonEliminarDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(botonActualizarDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(botonLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(busquedaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(busquedaCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonBuscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonBuscarCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(31, 31, 31)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonBusquedaTDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonEliminarDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonActualizarDueños, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(49, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerrarActionPerformed
        PgPrincipalVeterinaria principal = new PgPrincipalVeterinaria();
        principal.setVisible(true);
        this.dispose(); //
    }//GEN-LAST:event_botonCerrarActionPerformed

    private void nombreDueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreDueñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreDueñoActionPerformed

    private void cedulaDueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cedulaDueñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cedulaDueñoActionPerformed

    private void edadDueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edadDueñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edadDueñoActionPerformed

    private void celularDueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_celularDueñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_celularDueñoActionPerformed

    private void direccionDueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_direccionDueñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_direccionDueñoActionPerformed

    private void correoDueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_correoDueñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_correoDueñoActionPerformed

    private void botonRegistrarDueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarDueActionPerformed
        registrarDueño ();
    }//GEN-LAST:event_botonRegistrarDueActionPerformed

    private void botonCanceDueñosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCanceDueñosActionPerformed
        nombreDueño.setText("");
        cedulaDueño.setText("");
        edadDueño.setText("");
        celularDueño.setText("");
        direccionDueño.setText("");
        correoDueño.setText("");
        habilitarDueño();

    }//GEN-LAST:event_botonCanceDueñosActionPerformed

    private void tablaDueñosAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tablaDueñosAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaDueñosAncestorAdded

    private void botonBusquedaTDueñosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBusquedaTDueñosActionPerformed
        try {
            seleccionar ();
        } catch (SQLException ex) {
            Logger.getLogger(RegDueños.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_botonBusquedaTDueñosActionPerformed

    private void busquedaNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_busquedaNombreActionPerformed

    private void botonBuscarCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarCedulaActionPerformed
        busquedaCedula ();
    }//GEN-LAST:event_botonBuscarCedulaActionPerformed

    private void busquedaCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_busquedaCedulaActionPerformed

    private void botonBuscarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarNombreActionPerformed
        busquedaNombre ();        // TODO add your handling code here:
    }//GEN-LAST:event_botonBuscarNombreActionPerformed

    private void botonEliminarDueñosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarDueñosActionPerformed
       eliminarDueños ();
    }//GEN-LAST:event_botonEliminarDueñosActionPerformed

    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
        DefaultTableModel model = (DefaultTableModel) tablaDueños.getModel();
        model.setRowCount(0); 
    }//GEN-LAST:event_botonLimpiarActionPerformed

    private void botonActualizarDueñosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarDueñosActionPerformed
       mostrarDueño ();
         
    }//GEN-LAST:event_botonActualizarDueñosActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        if (cedulaDueño.getText().isEmpty() && CamposVacios()) {
        JOptionPane.showMessageDialog(this, "Los cambios solo se guardan cuando desea actualizar un dato registrado previamente.");
    } else {
        actualizarDueño();
    }
        
    }//GEN-LAST:event_botonGuardarActionPerformed
 public static Connection conectar_base () { //Conectar java con la base de datos
		Connection connection = null;
		try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al registrar el driver de PostgreSQL: " + ex);
        }
		// Database connect
		// Conectamos con la base de datos
        try {			
            connection = (Connection) DriverManager.getConnection(
            		"jdbc:postgresql://127.0.0.1:5432/Proyecto","postgres", "Basededatos");
        } catch (SQLException throwables) {
        }
		return connection;
       
	}
    
 
   public void seleccionar  ( ) throws SQLException {
        Connection connection = RegDueños.conectar_base();
        Statement stmt = null; // Objeto de tipo sentencia SQL
 
       DefaultTableModel model = new DefaultTableModel();
    
        model.addColumn("Nombre Dueño");
        model.addColumn("Cédula (ID)");
        model.addColumn("Edad");
        model.addColumn("Celular");
        model.addColumn("Direccion");
        model.addColumn("E-mail");
        
        tablaDueños.setModel(model);
        
        String []datos = new String [6];
        
        try {
            
          stmt = connection.createStatement();
          ResultSet rs = stmt.executeQuery("Select * from PersonasDueños");
  
          
          while ( rs.next ()){
               datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                
                model.addRow(datos);
          }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
                  

}
   
   private boolean verificarNombre(String nombre) {
    return nombre.length() > 0;
}

private boolean verificarEdad(int edad) {
    return edad >= 18;
}

private boolean verificarCelular(String celular) {
    long numeroCelular;
    try {
        numeroCelular = Long.parseLong(celular);
    } catch (NumberFormatException e) {
        return false; 
    }
    return numeroCelular > 2999999999L && numeroCelular <= 39999999999L;
}

private boolean verificarCedula(String cedula) {
    long id;
    try {
        id = Long.parseLong(cedula);
    } catch (NumberFormatException e) {
        return false; 
    }
    return id >= 10000000 && id <= 1999999999;
}

private boolean verificarCorreo(String correo) {
    return correo.contains("@gmail.com") || correo.contains("@hotmail.com")|| correo.contains("@outlook.com");
}

private boolean verificarDireccion(String direccion) {
    return direccion.contains("Calle") || direccion.contains("Carrera") || direccion.contains("Avenida") && direccion.contains("#");
}

private boolean validarDatos(String nombre, String cedula, int edad, String celular, String correo, String direccion) {
    if (!verificarNombre(nombre)) {
        JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío.");
        return false;
    }
    if (!verificarEdad(edad)) {
        JOptionPane.showMessageDialog(this, "Debe ser mayor de edad para registrarse.");
        return false;
    }
    if (!verificarCelular(celular)) {
        JOptionPane.showMessageDialog(this, "El número de celular no es válido.");
        return false;
    }
    if (!verificarCedula(cedula)) {
        JOptionPane.showMessageDialog(this, "La cédula no es válida.");
        return false;
    }
    if (!verificarCorreo(correo)) {
        JOptionPane.showMessageDialog(this, "El correo no es válido.");
        return false;
    }
    if (!verificarDireccion(direccion)) {
        JOptionPane.showMessageDialog(this, "La dirección no es válida.");
        return false;
    }
    return true;
}

private void registrarDueño() {
    String nombre = nombreDueño.getText();
    String cedula = cedulaDueño.getText();
    String edadText = edadDueño.getText();
    String celular = celularDueño.getText();
    String direccion = direccionDueño.getText();
    String correo = correoDueño.getText();

    if (nombre.isEmpty() || cedula.isEmpty() || edadText.isEmpty() || celular.isEmpty() || direccion.isEmpty() || correo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
        return;
    }

    int edad;
    try {
        edad = Integer.parseInt(edadText);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "La edad debe ser un número entero.");
        return;
    }

    if (!validarDatos(nombre, cedula, edad, celular, correo, direccion)) {
        return; 
    }

    try {
        Connection connection = conectar_base();
        PreparedStatement pst = connection.prepareStatement("INSERT INTO PersonasDueños VALUES (?, ?, ?, ?, ?, ?)");
        pst.setString(1, nombre);
        pst.setLong(2, Long.parseLong(cedula)); 
        pst.setInt(3, edad);
        pst.setLong(4, Long.parseLong(celular)); 
        pst.setString(5, direccion);
        pst.setString(6, correo);
        int rowsAffected = pst.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Dueño registrado correctamente");
            nombreDueño.setText("");
            cedulaDueño.setText("");
            edadDueño.setText("");
            celularDueño.setText("");
            direccionDueño.setText("");
            correoDueño.setText("");
            habilitarDueño();
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar dueño.");
        }
    } catch (SQLException ex) {
        Logger.getLogger(RegDueños.class.getName()).log(Level.SEVERE, null, ex);
        if (ex.getSQLState().equals("23505")) {
            JOptionPane.showMessageDialog(this, "La cédula ingresada ya se encuentra registrada.");
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar dueño: " + ex.getMessage());
        }
    }
}

private void busquedaNombre() {
    String nombreBusqueda = busquedaNombre.getText(); 

    if (nombreBusqueda.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingrese un nombre para buscar.");
        return;
    }

    Connection connection = null;
    Statement stmt = null;
    ResultSet rs = null;

    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Nombre Dueño");
    model.addColumn("Cédula (ID)");
    model.addColumn("Edad");
    model.addColumn("Celular");
    model.addColumn("Direccion");
    model.addColumn("E-mail");

    tablaDueños.setModel(model); 

    try {
        connection = conectar_base();
        stmt = connection.createStatement();
        rs = stmt.executeQuery("select * from PersonasDueños where NombrePersona = '" + nombreBusqueda + "'");

        String[] datos = new String[6];
        boolean encontrado = false;
        while (rs.next()) {
            encontrado = true;
            datos[0] = rs.getString("NombrePersona");
            datos[1] = String.valueOf(rs.getLong("IdDueño"));
            datos[2] = String.valueOf(rs.getInt("Edad"));
            datos[3] = String.valueOf(rs.getLong("Celular"));
            datos[4] = rs.getString("Direccion");
            datos[5] = rs.getString("Correo");

            model.addRow(datos);
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this, "No se encontraron resultados para el nombre: " + nombreBusqueda);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al buscar dueño: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cerrar la conexión: " + e.getMessage());
            e.printStackTrace(); 
        }
    }
}

private void busquedaCedula() {
    String cedulaBusqueda = busquedaCedula.getText(); 

    if (cedulaBusqueda.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingrese una cédula para buscar.");
        return;
    }

    Connection connection = null;
    Statement stmt = null;
    ResultSet rs = null;

    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Nombre Dueño");
    model.addColumn("Cédula (ID)");
    model.addColumn("Edad");
    model.addColumn("Celular");
    model.addColumn("Direccion");
    model.addColumn("E-mail");

    tablaDueños.setModel(model); 

    try {
        connection = conectar_base();
        stmt = connection.createStatement();
        rs = stmt.executeQuery("select * from PersonasDueños where IdDueño = '" + cedulaBusqueda + "'");

        String[] datos = new String[6];
        boolean encontrado = false;
        while (rs.next()) {
            encontrado = true;
            datos[0] = rs.getString("NombrePersona");
            datos[1] = String.valueOf(rs.getLong("IdDueño"));
            datos[2] = String.valueOf(rs.getInt("Edad"));
            datos[3] = String.valueOf(rs.getLong("Celular"));
            datos[4] = rs.getString("Direccion");
            datos[5] = rs.getString("Correo");

            model.addRow(datos);
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this, "No se encontraron resultados para la cédula: " + cedulaBusqueda);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al buscar dueño: " + e.getMessage());
        e.printStackTrace(); 
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cerrar la conexión: " + e.getMessage());
            e.printStackTrace(); 
        }
    }
}



    public void EliminarRegistro (String id){
        String sql = "delete from PersonasDueños where IdDueño = " + id;
        Statement st;
        Connection conexion = conectar_base ();
        
        try{
            st =conexion.createStatement();
            int rs =st.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Se ha eliminado correctamente");
        } catch (SQLException e){
            System.out.println(e);
        }
    }
    
    private void eliminarDueños() {
    int selectedRow = tablaDueños.getSelectedRow();

    if (selectedRow != -1) { 
        
        String id = tablaDueños.getValueAt(selectedRow, 1).toString();

        RegDueños regDueños = new RegDueños();
        regDueños.EliminarRegistro(id);

        DefaultTableModel model = (DefaultTableModel) tablaDueños.getModel();
        model.removeRow(selectedRow);
    } else {
        JOptionPane.showMessageDialog(null, "Seleccione un registro para eliminar.");
    }
}
private void actualizarRegistro(JTextField nombreDueño, JTextField edadDueño, JTextField celularDueño, 
        JTextField direccionDueño, JTextField correoDueño, String id) {

    String sql = "UPDATE PersonasDueños SET NombrePersona = '" + nombreDueño.getText() 
            + "', Edad = '" + edadDueño.getText() + "', Celular = '" + celularDueño.getText()
            + "', Direccion = '" + direccionDueño.getText() + "', Correo = '" + correoDueño.getText() 
            + "' WHERE IdDueño = " + id;
    
    Connection conexion = conectar_base();
    try (Statement st = conexion.createStatement()) {
        int rs = st.executeUpdate(sql);
        JOptionPane.showMessageDialog(null, "Se ha actualizado correctamente");
    } catch (SQLException e) {
        System.out.println(e);
        JOptionPane.showMessageDialog(null, "Error al actualizar: " + e.getMessage());
    }
}

private void mostrarDueño() {
    int filaSeleccionada = tablaDueños.getSelectedRow();

    if (filaSeleccionada >= 0) {
        DefaultTableModel model = (DefaultTableModel) tablaDueños.getModel();

        String idDueño = model.getValueAt(filaSeleccionada, 1).toString();
        String nombre = model.getValueAt(filaSeleccionada, 0).toString();
        String edad = model.getValueAt(filaSeleccionada, 2).toString();
        String celular = model.getValueAt(filaSeleccionada, 3).toString();
        String direccion = model.getValueAt(filaSeleccionada, 4).toString();
        String correo = model.getValueAt(filaSeleccionada, 5).toString();

        nombreDueño.setText(nombre);
        cedulaDueño.setText(idDueño);
        edadDueño.setText(edad);
        celularDueño.setText(celular);
        direccionDueño.setText(direccion);
        correoDueño.setText(correo);

        cancelarOperacion();
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione una fila para actualizar.");
    }
}

private void actualizarDueño() {
    int filaSeleccionada = tablaDueños.getSelectedRow();

    if (filaSeleccionada >= 0) {
        DefaultTableModel model = (DefaultTableModel) tablaDueños.getModel();

        String idDueño = model.getValueAt(filaSeleccionada, 1).toString();
        String nombre = nombreDueño.getText();
        String edad = edadDueño.getText();
        String celular = celularDueño.getText();
        String direccion = direccionDueño.getText();
        String correo = correoDueño.getText();

        try (Connection connection = conectar_base();
             PreparedStatement pstmt = connection.prepareStatement("UPDATE PersonasDueños SET NombrePersona =?, Edad =?, Celular =?, Direccion =?, Correo =? WHERE IdDueño =?")) {

            pstmt.setString(1, nombre);
            pstmt.setInt(2, Integer.parseInt(edad));
            pstmt.setLong(3, Long.parseLong(celular));
            pstmt.setString(4, direccion);
            pstmt.setString(5, correo);
            pstmt.setInt(6, Integer.parseInt(idDueño));

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Los datos se actualizaron correctamente.");

                model.setRowCount(0);

                nombreDueño.setText("");
                cedulaDueño.setText("");
                edadDueño.setText("");
                celularDueño.setText("");
                direccionDueño.setText("");
                correoDueño.setText("");
                habilitarDueño();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudieron actualizar los datos.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar los datos: " + e.getMessage());
        }
    }
}
    private void habilitarDueño() {
    //...
    cedulaDueño.setEnabled(true); 
    //...
}

private void cancelarOperacion() {
    //...
    cedulaDueño.setEnabled(false); 
}

private boolean CamposVacios() {
    return nombreDueño.getText().isEmpty() || cedulaDueño.getText().isEmpty() || edadDueño.getText().isEmpty() || celularDueño.getText().isEmpty()
            || direccionDueño.getText().isEmpty()|| correoDueño.getText().isEmpty() ;
}

   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegDueños().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizarDueños;
    private javax.swing.JButton botonBuscarCedula;
    private javax.swing.JButton botonBuscarNombre;
    private javax.swing.JButton botonBusquedaTDueños;
    private javax.swing.JButton botonCanceDueños;
    private javax.swing.JButton botonCerrar;
    private javax.swing.JButton botonEliminarDueños;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonLimpiar;
    private javax.swing.JButton botonRegistrarDue;
    private javax.swing.JTextField busquedaCedula;
    private javax.swing.JTextField busquedaNombre;
    private javax.swing.JTextField cedulaDueño;
    private javax.swing.JTextField celularDueño;
    private javax.swing.JTextField correoDueño;
    private javax.swing.JTextField direccionDueño;
    private javax.swing.JTextField edadDueño;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField nombreDueño;
    private javax.swing.JTable tablaDueños;
    // End of variables declaration//GEN-END:variables
}
