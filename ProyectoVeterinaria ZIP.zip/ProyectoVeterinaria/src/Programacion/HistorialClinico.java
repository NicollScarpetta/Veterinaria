/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Programacion;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import Programacion.PgPrincipalVeterinaria;

/**
 *
 * @author nicol
 */
public class HistorialClinico extends javax.swing.JFrame {
    
private boolean vacunado = false;
private boolean desparasitado = false;
private ArrayList<String> veterinarios = new ArrayList<>();
private ArrayList<Integer> idsVeterinarios = new ArrayList<>();

    /**
     * Creates new form HistorialClinico
     */
    public HistorialClinico() {
        initComponents();
        cargarVeterinarios();
    }
 public static Connection conectar_base () { //Conectar java con la base de datos
		Connection connection = null;
		try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al registrar el driver de PostgreSQL: " + ex);
        }
		// Database connect
		// Conectamos con la base de datos
        try {			
            connection = (Connection) DriverManager.getConnection(
            		"jdbc:postgresql://127.0.0.1:5432/Proyecto","postgres", "Basededatos");
        } catch (SQLException throwables) {
        }
		return connection;
       
	}
    
    
     public void seleccionar  ( ) throws SQLException {
        Connection connection = HistorialClinico.conectar_base();
        Statement stmt = null; // Objeto de tipo sentencia SQL
 
       DefaultTableModel model = new DefaultTableModel();
    
        model.addColumn("ID Historial");
        model.addColumn("Ingreso");
        model.addColumn("Consulta clinica");
        model.addColumn("Enfermedades");
        model.addColumn("Vacunado");
        model.addColumn("Desparasitado");
        model.addColumn("Veterinario (ID)");

        
        tablaHistorial.setModel(model);
        
        String []datos = new String [7];
        
        try {
            
          stmt = connection.createStatement();
          ResultSet rs = stmt.executeQuery("Select * from HistorialClinico");
  
          
          while ( rs.next ()){
               datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                
                model.addRow(datos);
          }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
                  

}
     private void busquedaPaciente() {
    String numBusqueda = numeroPacienteMasc.getText(); 

    if (numBusqueda.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingrese un numero de paciente para buscar.");
        return;
    }

    Connection connection = null;
    Statement stmt = null;
    ResultSet rs = null;

    DefaultTableModel model = new DefaultTableModel();
       model.addColumn("ID Historial");
        model.addColumn("Ingreso");
        model.addColumn("Consulta clinica");
        model.addColumn("Enfermedades");
        model.addColumn("Vacunado");
        model.addColumn("Desparasitado");
        model.addColumn("Veterinario (ID)");

         tablaHistorial.setModel(model); 

    try {
        connection = conectar_base();
        stmt = connection.createStatement();
        rs = stmt.executeQuery("select * from HistorialClinico where IdHistorial = '" + numBusqueda + "'");

        String[] datos = new String[7];
        boolean encontrado = false;
        while (rs.next()) {
            encontrado = true;
            datos[0] = rs.getString("IdHistorial");
            datos[1] = rs.getString("FechaHoraIngreso");
            datos[2] = rs.getString("TemaConsulta");
            datos[3] = rs.getString("Enfermedades");
            datos[4] = rs.getString("Vacunado");
            datos[5] = rs.getString("Desparasitado");
            datos[6] = String.valueOf(rs.getLong("IdMedico"));
            

            model.addRow(datos);
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this, "No se encontraron resultados para el numero de paciente: " + numBusqueda);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al buscar Paciente: " + e.getMessage());
        e.printStackTrace(); 
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cerrar la conexión: " + e.getMessage());
            e.printStackTrace(); 
        }
    }
}
 private void cargarVeterinarios() {
    try (Connection connection = HistorialClinico.conectar_base()) {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT IdMedico FROM Veterinarios");

        while (rs.next()) {
            int idVeterinario = rs.getInt("IdMedico");
            idsVeterinarios.add(idVeterinario);
            comboboxVeterinarios.addItem(String.valueOf(idVeterinario));
        }

        rs.close();
        stmt.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al cargar veterinarios: " + e.getMessage());
    }
}
    
    
  private void mostrarDatos() {
    int filaSeleccionada = tablaHistorial.getSelectedRow();

    if (filaSeleccionada >= 0) {
        DefaultTableModel model = (DefaultTableModel) tablaHistorial.getModel();

        String idpaciente = model.getValueAt(filaSeleccionada, 0).toString();
        String ingreso = model.getValueAt(filaSeleccionada, 1).toString();

        idHistorial.setText(idpaciente);
        ingresoHistoria.setText(ingreso);

        revisionMedica.setText("");
        enfermedadesMed.setText("");
        boxVacunado.setSelected(false);
        boxDesparasitado.setSelected(false);
        

        idHistorial.setEnabled(false);
        ingresoHistoria.setEnabled(false);
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione una fila para actualizar.");
    }
}
    private void actualizarDatos() {
    int filaSeleccionada = tablaHistorial.getSelectedRow();

    if (filaSeleccionada >= 0) {
        DefaultTableModel model = (DefaultTableModel) tablaHistorial.getModel();

        String consultaClinica = revisionMedica.getText();
        String enfermedades = enfermedadesMed.getText();
        String vacuna = boxVacunado.isSelected()? "Vacunado" : "No vacunado";
        String desparasitacion = boxDesparasitado.isSelected()? "Desparasitado" : "No desparasitado";
        String veterinarioSeleccionado = (String) comboboxVeterinarios.getSelectedItem();

        try (Connection connection = conectar_base();
             PreparedStatement pstmt = connection.prepareStatement("UPDATE HistorialClinico SET TemaConsulta =?, Enfermedades =?, Vacunado =?, Desparasitado =?, IdMedico =? WHERE IdHistorial =?")) {

            pstmt.setString(1, consultaClinica);
            pstmt.setString(2, enfermedades);
            pstmt.setBoolean(3, boxVacunado.isSelected());
            pstmt.setBoolean(4, boxDesparasitado.isSelected());
            pstmt.setInt(5, Integer.parseInt(veterinarioSeleccionado));
            pstmt.setInt(6, Integer.parseInt(idHistorial.getText()));

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Los datos se actualizaron correctamente.");

                model.setRowCount(0);

                idHistorial.setText("");
                ingresoHistoria.setText("");
                revisionMedica.setText("");
                enfermedadesMed.setText("");
                boxVacunado.setSelected(false);
                boxDesparasitado.setSelected(false);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudieron actualizar los datos.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar los datos: " + e.getMessage());
        }
    }
}
  
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaHistorial = new javax.swing.JTable();
        botonBusquedaHist = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        numeroPacienteMasc = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        botonBuscarNM = new javax.swing.JButton();
        botonActualizarHist = new javax.swing.JButton();
        botonLimpiar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        enfermedadesMed = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        botonGuardarConsulta = new javax.swing.JButton();
        botonCanceConsult = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        revisionMedica = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        idHistorial = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        ingresoHistoria = new javax.swing.JTextField();
        boxVacunado = new javax.swing.JCheckBox();
        boxDesparasitado = new javax.swing.JCheckBox();
        comboboxVeterinarios = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        botonCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(171, 221, 220));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        tablaHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Historial", "Ingreso", "Consulta", "Enfermedades", "Vacunado", "Desparasitado", "Veterinario (ID)"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaHistorial.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tablaHistorialAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(tablaHistorial);

        botonBusquedaHist.setBackground(new java.awt.Color(171, 221, 220));
        botonBusquedaHist.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonBusquedaHist.setText("Filtrar datos");
        botonBusquedaHist.setToolTipText("");
        botonBusquedaHist.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonBusquedaHist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBusquedaHistActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Numero Paciente (Mascota):");

        numeroPacienteMasc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        numeroPacienteMasc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        numeroPacienteMasc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numeroPacienteMascActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(171, 221, 220));

        jLabel10.setBackground(new java.awt.Color(171, 221, 220));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Historial Clinico");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        botonBuscarNM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectobases/Veterinaria/lupita.png"))); // NOI18N
        botonBuscarNM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarNMActionPerformed(evt);
            }
        });

        botonActualizarHist.setBackground(new java.awt.Color(171, 221, 220));
        botonActualizarHist.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonActualizarHist.setText("Actualizar Consulta");
        botonActualizarHist.setToolTipText("");
        botonActualizarHist.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonActualizarHist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarHistActionPerformed(evt);
            }
        });

        botonLimpiar.setBackground(new java.awt.Color(171, 221, 220));
        botonLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonLimpiar.setText("Limpiar");
        botonLimpiar.setToolTipText("");
        botonLimpiar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(261, 261, 261))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addComponent(jLabel12)
                .addGap(38, 38, 38)
                .addComponent(numeroPacienteMasc, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(botonBuscarNM, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(botonBusquedaHist, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(89, 89, 89)
                .addComponent(botonActualizarHist, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85)
                .addComponent(botonLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(88, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(numeroPacienteMasc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(botonBuscarNM, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonActualizarHist, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonBusquedaHist, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(171, 221, 220));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Consulta Clinica");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Revisión medica");

        enfermedadesMed.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        enfermedadesMed.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        enfermedadesMed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enfermedadesMedActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Enfermedades");

        botonGuardarConsulta.setBackground(new java.awt.Color(171, 221, 220));
        botonGuardarConsulta.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonGuardarConsulta.setText("Guardar");
        botonGuardarConsulta.setToolTipText("");
        botonGuardarConsulta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonGuardarConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarConsultaActionPerformed(evt);
            }
        });

        botonCanceConsult.setBackground(new java.awt.Color(171, 221, 220));
        botonCanceConsult.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonCanceConsult.setText("Cancelar");
        botonCanceConsult.setToolTipText("");
        botonCanceConsult.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonCanceConsult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCanceConsultActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectobases/Veterinaria/Historial (1).png"))); // NOI18N

        revisionMedica.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        revisionMedica.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        revisionMedica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                revisionMedicaActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("ID Historial:");

        idHistorial.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        idHistorial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        idHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idHistorialActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Ingreso:");

        ingresoHistoria.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ingresoHistoria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ingresoHistoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingresoHistoriaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 58, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(revisionMedica, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(enfermedadesMed, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(35, 35, 35)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(idHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(ingresoHistoria, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(93, 93, 93)
                                .addComponent(jLabel4)))))
                .addGap(39, 39, 39))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(119, 119, 119)
                .addComponent(botonGuardarConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81)
                .addComponent(botonCanceConsult, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ingresoHistoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(revisionMedica, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(enfermedadesMed, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 148, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonGuardarConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonCanceConsult, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36))
        );

        boxVacunado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        boxVacunado.setText("Vacunado");
        boxVacunado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxVacunadoActionPerformed(evt);
            }
        });

        boxDesparasitado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        boxDesparasitado.setText("Desparasitado");
        boxDesparasitado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxDesparasitadoActionPerformed(evt);
            }
        });

        comboboxVeterinarios.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        comboboxVeterinarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboboxVeterinariosActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Veterinario que atendio:");

        botonCerrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonCerrar.setText("Cerrar");
        botonCerrar.setToolTipText("");
        botonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addComponent(jLabel6)
                        .addGap(46, 46, 46)
                        .addComponent(comboboxVeterinarios, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(153, 153, 153)
                        .addComponent(boxVacunado)
                        .addGap(70, 70, 70)
                        .addComponent(boxDesparasitado)))
                .addContainerGap(949, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(botonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(34, 34, 34)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(469, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boxVacunado)
                    .addComponent(boxDesparasitado))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboboxVeterinarios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(122, 122, 122)
                .addComponent(botonCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(34, 34, 34)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addContainerGap(36, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tablaHistorialAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tablaHistorialAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaHistorialAncestorAdded

    private void botonBusquedaHistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBusquedaHistActionPerformed
        try {
            seleccionar ();
        } catch (SQLException ex) {
            Logger.getLogger(HistorialClinico.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_botonBusquedaHistActionPerformed

    private void numeroPacienteMascActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numeroPacienteMascActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numeroPacienteMascActionPerformed

    private void botonBuscarNMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarNMActionPerformed
          busquedaPaciente ();
    }//GEN-LAST:event_botonBuscarNMActionPerformed

    private void botonActualizarHistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarHistActionPerformed
    mostrarDatos();
    }//GEN-LAST:event_botonActualizarHistActionPerformed

    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
        DefaultTableModel model = (DefaultTableModel) tablaHistorial.getModel();
        model.setRowCount(0);
    }//GEN-LAST:event_botonLimpiarActionPerformed

    private void enfermedadesMedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enfermedadesMedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enfermedadesMedActionPerformed

    private void botonGuardarConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarConsultaActionPerformed
    actualizarDatos();
    }//GEN-LAST:event_botonGuardarConsultaActionPerformed

    private void botonCanceConsultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCanceConsultActionPerformed
                idHistorial.setText ("");
                ingresoHistoria.setText("");
                revisionMedica.setText("");
                enfermedadesMed.setText("");
                boxVacunado.setSelected(false);
                boxDesparasitado.setSelected(false);
                comboboxVeterinarios.setSelectedIndex(-1);
    }//GEN-LAST:event_botonCanceConsultActionPerformed

    private void revisionMedicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_revisionMedicaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_revisionMedicaActionPerformed

    private void boxVacunadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxVacunadoActionPerformed
        vacunado = boxVacunado.isSelected();
    }//GEN-LAST:event_boxVacunadoActionPerformed

    private void comboboxVeterinariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboboxVeterinariosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboboxVeterinariosActionPerformed

    private void botonCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerrarActionPerformed
        PgPrincipalVeterinaria principal = new PgPrincipalVeterinaria();
        principal.setVisible(true); 
        this.dispose(); 
    }//GEN-LAST:event_botonCerrarActionPerformed

    private void boxDesparasitadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxDesparasitadoActionPerformed
        desparasitado = boxDesparasitado.isSelected();
    }//GEN-LAST:event_boxDesparasitadoActionPerformed

    private void idHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idHistorialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idHistorialActionPerformed

    private void ingresoHistoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingresoHistoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ingresoHistoriaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HistorialClinico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HistorialClinico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HistorialClinico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HistorialClinico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HistorialClinico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizarHist;
    private javax.swing.JButton botonBuscarNM;
    private javax.swing.JButton botonBusquedaHist;
    private javax.swing.JButton botonCanceConsult;
    private javax.swing.JButton botonCerrar;
    private javax.swing.JButton botonGuardarConsulta;
    private javax.swing.JButton botonLimpiar;
    private javax.swing.JCheckBox boxDesparasitado;
    private javax.swing.JCheckBox boxVacunado;
    private javax.swing.JComboBox<String> comboboxVeterinarios;
    private javax.swing.JTextField enfermedadesMed;
    private javax.swing.JTextField idHistorial;
    private javax.swing.JTextField ingresoHistoria;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField numeroPacienteMasc;
    private javax.swing.JTextField revisionMedica;
    private javax.swing.JTable tablaHistorial;
    // End of variables declaration//GEN-END:variables
}
